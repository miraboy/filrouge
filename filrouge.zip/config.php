<?php 
    define('DB_HOST','mysql:host=localhost;'); // Nom d'hote du serveur de base de données
    define('DB_NAME','dbname=based'); // Nom de la base de données
    define('DB_USER','root'); // L'utilisateur de la db
    define('DB_PASS',''); // Le mot de passe pour accéder à la db
?> 