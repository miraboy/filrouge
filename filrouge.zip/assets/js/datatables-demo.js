// Call the dataTables jQuery plugin
$(document).ready(function() {
  $('#cartes').DataTable();
  $('#comptes').DataTable();
});
