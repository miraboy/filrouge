<?php
    // Inclusion des fichiers nécessaires
    include 'donnees.php';
    include 'entreprise.php';
    
    // Initialisation des variables
    $contenuePrincipale = "";
    $msg = "";
    
    // Vérification si une action est demandée via GET ou POST
    if (!empty($_GET['action']) || isset($_POST['action'])) {
        $action = htmlspecialchars($_GET['action']);
        $entreprise = new Entreprise("", "", "", 0, "");

        // Switch sur les différentes actions possibles
        switch ($action) {
            // Test de connexion à la base de données
            case "tester":
                $connection = connecter();
                if($connection) {
                    $contenuePrincipale = "<h3 class='m-5'>Connexion établie</h3>";
                } else {
                    $contenuePrincipale = "<h3 class='m-5'>Connexion non établie</h3>";
                }
                break;

            // Affichage de la liste des entreprises
            case 'afficher':
                // Récupération et traitement des entreprises
                $entreprises = $entreprise->getAll();
                
                // Tri si des paramètres de tri sont fournis
                if(isset($_GET['fonction']) && isset($_GET['clef']) && isset($_GET['ordre'])) {
                    $clef = $_GET['clef'];
                    $ordre = $_GET['ordre'];
                    $entreprises = trierParCle($entreprises, $clef, $ordre);
                }
                
                // Pagination
                $parPage = 10;
                $page = isset($_GET['page']) ? $_GET['page'] : 1;
                $total = count($entreprises);
                $totalPages = ceil($total / $parPage);
                $entreprises = paginerTab($parPage, $page, $entreprises);

                // Construction de l'interface
                $contenuePrincipale .= '<p class="lead text-uppercase mt-4">Les entreprises</p>';
                $contenuePrincipale .= '
                    <div class="col-md-8">
                        <form method="get" action="./index.php">
                            <input type="hidden" name="action" value="afficher">
                            <input type="hidden" name="fonction" value="trier">
                            <span class="d-flex">
                                <label for="clef" class="col-2">Trier par</label>
                                <select id="clef" name="clef" class="form-control border-primary">
                                    <option value="id">Id</option>
                                    <option value="nom">Nom</option>
                                    <option value="description">Description</option>
                                    <option value="adresse">Adresse</option>
                                    <option value="nbrEmp">Nombre d\'employé</option>
                                    <option value="dateC">Date de création</option>
                                </select>
                                <select id="ordre" name="ordre" class="form-control border-primary mx-2">
                                    <option value="asc">Croissant</option>
                                    <option value="desc">Décroissant</option>
                                </select>
                                <button class="btn btn-primary" type="submit">Trier</button>
                            </span>
                        </form>
                    </div>';
                
                // Tableau des entreprises
                $contenuePrincipale .= "<div class='table-responsive'>";
                $contenuePrincipale .= "<table class='table table-striped'>";
                $contenuePrincipale .= "<thead class='thead-dark'><tr>
                    <th scope='col'>ID</th>
                    <th scope='col'>Photo</th>
                    <th scope='col'>Nom</th>
                    <th scope='col'>Description</th>
                    <th scope='col'>Adresse</th>
                    <th scope='col'>Nombre d'employé</th>
                    <th scope='col'>Date de création</th>
                    <th>Action</th>
                </tr></thead>";
                $contenuePrincipale .= "<tbody>";
                
                foreach ($entreprises as $entreprise) {
                    $contenuePrincipale .= $entreprise;
                }
                
                $contenuePrincipale .= "</tbody></table></div>";
                
                // Pagination
                $contenuePrincipale .= "<div class='my-2 text-center'>";
                if ($page > 1) {
                    $prev = $page - 1;
                    $contenuePrincipale .= "<a class='btn btn-info' href='?action=afficher&page=$prev&parPage=$parPage'>Prev</a> ";
                } else {
                    $contenuePrincipale .= "<span class='btn btn-secondary'>Prev</span> ";
                }
                
                for ($i = 1; $i <= $totalPages; $i++) {
                    if ($i == $page) {
                        $contenuePrincipale .= "<strong class='btn btn-primary'>$i</strong> ";
                    } else {
                        $contenuePrincipale .= "<a class='btn btn-secondary' href='?action=afficher&page=$i&parPage=$parPage'>$i</a> ";
                    }
                }
                
                if ($page < $totalPages) {
                    $next = $page + 1;
                    $contenuePrincipale .= "<a class='btn btn-info' href='?action=afficher&page=$next&parPage=$parPage'>Next</a>";
                } else {
                    $contenuePrincipale .= "<span class='btn btn-secondary'>Next</span>";
                }
                
                $contenuePrincipale .= "</div>";
                break;

            // Affichage détaillé d'une entreprise
            case "voir":
                if(!isset($_GET['id'])) {
                    header("Location: ./index.php?action=afficher");
                    exit;
                }
                
                $id = htmlspecialchars($_GET['id']);
                $entreprise = $entreprise->rechercherParId($id); // Correction: remplacé rechercherParId() par rechercherParId()
                
                $contenuePrincipale .= '
                <p class="lead text-center my-4">Entreprise '.$entreprise->getId().'</p>
                <form method="POST">
                    <div class="form-group">
                        <label for="nom">Nom :</label>
                        <input type="text" class="form-control" id="nom" name="nom" value="'.$entreprise->getNom().'" required disabled>
                    </div>
                    <div class="form-group">
                        <label for="description">Description :</label>
                        <input type="text" class="form-control" id="description" name="description" value="'.$entreprise->getDescription().'" required disabled>
                    </div>
                    <div class="form-group">
                        <label for="adresse">Adresse :</label>
                        <input type="text" class="form-control" id="adresse" name="adresse" value="'.$entreprise->getAdresse().'" required disabled>
                    </div>
                    <div class="form-group">
                        <label for="nbrEmp">Nombre d\'employé :</label>
                        <input type="text" class="form-control" id="nbrEmp" name="nbrEmp" value="'.$entreprise->getNbrEmp().'" required disabled>
                    </div>
                    <div class="form-group">
                        <label for="dateC">Date de création :</label>
                        <input type="text" class="form-control" id="dateC" name="dateC" value="'.$entreprise->getDateC().'" required disabled>
                    </div>
                    <a class="btn btn-primary btn-block my-4" href="./index.php?action=afficher">Retour</a>
                    <a class="btn btn-warning btn-block my-4" href="./index.php?action=modification_form&id='.$id.'">Modifier</a>
                </form>';
                break;

            // Confirmation de suppression
            case "confirmer_suppression":
                if(!isset($_GET['id'])) {
                    header("Location: ./index.php?action=afficher");
                    exit;
                }
                
                $id = htmlspecialchars($_GET['id']);
                $contenuePrincipale .= '
                <div class="alert alert-danger my-3 p-3">
                    <h4>Entreprise '.$id.'</h4>
                    <p>
                        Etes-vous sûr de supprimer cette entreprise ? Cette action est irréversible !<br>
                        <a class="btn btn-danger mt-3" href="./index.php?action=supprimer&id='.$id.'">Confirmer la suppression</a>
                    </p>
                </div>';
                break;

            // Suppression effective
            case "supprimer":
                if(!isset($_GET['id'])) {
                    header("Location: ./index.php?action=afficher");
                    exit;
                }
                
                $id = htmlspecialchars($_GET['id']);
                $entreprise = $entreprise->rechercherParId($id); // Correction: remplacé rechercherParId() par rechercherParId()
                
                if($entreprise && $entreprise->supprimer()) {
                    $contenuePrincipale .= '
                    <div class="alert alert-success my-3 p-3">
                        <h4>Entreprise '.$id.'</h4>
                        <p>
                            L\'entreprise a été supprimée avec succès.<br>
                            <a class="btn btn-success mt-3" href="./index.php?action=afficher">Retour</a>
                        </p>
                    </div>';
                } else {
                    $contenuePrincipale .= '
                    <div class="alert alert-info my-3 p-3">
                        <h4>Entreprise '.$id.'</h4>
                        <p>
                            L\'entreprise n\'existe pas ou n\'a pas pu être supprimée.<br>
                            <a class="btn btn-info mt-3" href="./index.php?action=afficher">Retour</a>
                        </p>
                    </div>';
                }
                break;

            // Formulaire de modification
            case "modification_form":
                if(!isset($_GET['id'])) {
                    header("Location: ./index.php?action=afficher");
                    exit;
                }
                
                $id = htmlspecialchars($_GET['id']);
                $entreprise = $entreprise->rechercherParId($id); // Correction: remplacé rechercherParId() par rechercherParId()
                
                $contenuePrincipale .= '
                <p class="lead text-center my-4">Entreprise '.$entreprise->getId().'</p>
                <form method="POST" action="./index.php?action=confirme_modification&id='.$entreprise->getId().'">
                    <div class="form-group">
                        <label for="nom">Nom :</label>
                        <input type="text" class="form-control" id="nom" name="nom" value="'.$entreprise->getNom().'" required>
                    </div>
                    <div class="form-group">
                        <label for="description">Description :</label>
                        <input type="text" class="form-control" id="description" name="description" value="'.$entreprise->getDescription().'" required>
                    </div>
                    <div class="form-group">
                        <label for="adresse">Adresse :</label>
                        <input type="text" class="form-control" id="adresse" name="adresse" value="'.$entreprise->getAdresse().'" required>
                    </div>
                    <div class="form-group">
                        <label for="nbrEmp">Nombre d\'employé :</label>
                        <input type="number" class="form-control" id="nbrEmp" name="nbrEmp" value="'.$entreprise->getNbrEmp().'" required>
                    </div>
                    <div class="form-group">
                        <label for="dateC">Date de création :</label>
                        <small><em>jj-mm-aaaa</em></small>
                        <input type="text" class="form-control" id="dateC" name="dateC" value="'.$entreprise->getDateC().'" required>
                    </div>
                    <button class="btn btn-warning btn-block my-4" type="submit">Modifier</button>
                    <a class="btn btn-primary btn-block my-4" href="./index.php?action=afficher">Retour</a>
                </form>';
                break;

            // Confirmation de modification
            case "confirme_modification":
                if(empty($_POST)) {
                    header("Location: ./index.php?action=afficher");
                    exit;
                }
                
                if(!isset($_GET['id'])) {
                    header("Location: ./index.php?action=afficher");
                    exit;
                }
                
                $id = htmlspecialchars($_GET['id']);
                
                if(validerForm($_POST)) {
                    $contenuePrincipale .= '
                    <div class="alert alert-warning my-3 p-3">
                        <h4>Entreprise '.$id.'</h4>
                        <p>
                            Etes-vous sûr de modifier cette entreprise ?<br>
                            <a class="btn btn-warning mt-3" href="./index.php?action=modifier&id='.$id.'">Confirmer la modification</a>
                        </p>
                    </div>';
                } else {
                    $contenuePrincipale .= '
                    <div class="alert alert-danger my-3 p-3">
                        <h4>Entreprise '.$id.'</h4>
                        <p>
                            Une erreur a été détectée !<br>
                            '.$_SESSION['error'].'<br>
                            <a class="btn btn-danger mt-3" href="./index.php?action=modification_form&id='.$id.'">Retour</a>
                        </p>
                    </div>';
                }
                break;

            // Modification effective
            case 'modifier':
                if(!isset($_GET['id'])) {
                    header("Location: ./index.php?action=afficher");
                    exit;
                }
                
                $id = htmlspecialchars($_GET['id']);
                $form = $_SESSION['form'];
                
                $entreprise = new Entreprise(
                    $form['nom'],
                    $form['description'],
                    $form['adresse'],
                    $form['nbrEmp'],
                    $form['dateC']
                );
                $entreprise->setId($id);
                
                if($entreprise->modifier()) {
                    $contenuePrincipale .= '
                    <div class="alert alert-success my-3 p-3">
                        <h4>Entreprise '.$id.'</h4>
                        <p>
                            Modification effectuée avec succès<br>
                            <a class="btn btn-success mt-3" href="./index.php?action=voir&id='.$id.'">Voir l\'entreprise</a>
                        </p>
                    </div>';
                    unset($_SESSION['form']);
                } else {
                    $contenuePrincipale .= '
                    <div class="alert alert-danger my-3 p-3">
                        <h4>Entreprise '.$id.'</h4>
                        <p>
                            Une erreur s\'est produite !<br>
                            <a class="btn btn-danger mt-3" href="./index.php?action=voir&id='.$id.'">Voir l\'entreprise</a>
                        </p>
                    </div>';
                }
                break;

            // Formulaire d'ajout
            case "ajouter_form":
                if(isset($_SESSION['form'])) {
                    $nom = $_SESSION['form']['nom'];
                    $description = $_SESSION['form']['description'];
                    $adresse = $_SESSION['form']['adresse'];
                    $nbrEmp = $_SESSION['form']['nbrEmp'];
                    $dateC = $_SESSION['form']['dateC'];
                } else {
                    $nom = $description = $adresse = $nbrEmp = $dateC = "";
                }
                
                $contenuePrincipale .= '
                <p class="lead text-center my-4">Ajouter une entreprise</p>
                <form method="POST" action="./index.php?action=confirme_ajout">
                    <div class="form-group">
                        <label for="nom">Nom :</label>
                        <input type="text" class="form-control" id="nom" name="nom" value="'.$nom.'" placeholder="Nom de l\'entreprise" required>
                    </div>
                    <div class="form-group">
                        <label for="description">Description :</label>
                        <input type="text" class="form-control" id="description" name="description" value="'.$description.'" placeholder="Description de l\'entreprise" required>
                    </div>
                    <div class="form-group">
                        <label for="adresse">Adresse :</label>
                        <input type="text" class="form-control" id="adresse" name="adresse" value="'.$adresse.'" placeholder="Adresse de l\'entreprise" required>
                    </div>
                    <div class="form-group">
                        <label for="nbrEmp">Nombre d\'employé :</label>
                        <input type="number" class="form-control" id="nbrEmp" name="nbrEmp" value="'.$nbrEmp.'" placeholder="Nombre d\'employés" required>
                    </div>
                    <div class="form-group">
                        <label for="dateC">Date de création :</label>
                        <input type="text" class="form-control" id="dateC" name="dateC" value="'.$dateC.'" placeholder="jj-mm-aaaa" required>
                    </div>
                    <button class="btn btn-warning btn-block my-4" type="submit">Ajouter</button>
                    <a class="btn btn-primary btn-block my-4" href="./index.php?action=afficher">Retour</a>
                </form>';
                break;

            // Confirmation d'ajout
            case "confirme_ajout":
                if(empty($_POST)) {
                    header("Location: ./index.php?action=afficher");
                    exit;
                }
                
                if(validerForm($_POST)) {
                    $contenuePrincipale .= '
                    <div class="alert alert-warning my-3 p-3">
                        <h4>Ajouter une entreprise</h4>
                        <p>
                            Etes-vous sûr d\'ajouter cette entreprise ?<br>
                            <a class="btn btn-warning mt-3" href="./index.php?action=ajouter">Confirmer l\'ajout</a>
                        </p>
                    </div>';
                } else {
                    $contenuePrincipale .= '
                    <div class="alert alert-danger my-3 p-3">
                        <h4>Entreprise</h4>
                        <p>
                            Une erreur a été détectée !<br>
                            '.$_SESSION['error'].'<br>
                            <a class="btn btn-danger mt-3" href="./index.php?action=ajouter_form">Retour</a>
                        </p>
                    </div>';
                }
                break;

            // Ajout effectif
            case 'ajouter':
                $form = $_SESSION['form'];
                $entreprise = new Entreprise(
                    $form['nom'],
                    $form['description'],
                    $form['adresse'],
                    $form['nbrEmp'],
                    $form['dateC']
                );
                
                if($entreprise->ajouter()) {
                    $contenuePrincipale .= '
                    <div class="alert alert-success my-3 p-3">
                        <h4>Entreprise</h4>
                        <p>
                            Ajout effectué avec succès<br>
                            <a class="btn btn-success mt-3" href="./index.php?action=afficher">Voir les entreprises</a>
                        </p>
                    </div>';
                    unset($_SESSION['form']);
                } else {
                    $contenuePrincipale .= '
                    <div class="alert alert-danger my-3 p-3">
                        <h4>Entreprise</h4>
                        <p>
                            Une erreur s\'est produite !<br>
                            <a class="btn btn-danger mt-3" href="./index.php?action=ajouter_form">Retour</a>
                        </p>
                    </div>';
                }
                break;

            // Recherche d'entreprises
            case 'rechercher':
                if(empty($_GET['clef'])) {
                    header("Location: ./index.php?action=afficher");
                    exit;
                }
                
                $clef = trim(htmlspecialchars($_GET['clef']));
                $entreprises = $entreprise->rechercherParClef($clef); // Correction: remplacé rechercherParClef() par rechercherParClef()
                
                $contenuePrincipale .= '<p class="lead my-4">Résultats pour "'.$clef.'"</p>';
                $contenuePrincipale .= '<div class="table-responsive">';
                $contenuePrincipale .= '<table class="table table-striped">';
                $contenuePrincipale .= '<thead class="thead-dark"><tr>
                    <th scope="col">ID</th>
                    <th scope="col">Nom</th>
                    <th scope="col">Description</th>
                    <th scope="col">Adresse</th>
                    <th scope="col">Nombre d\'employé</th>
                    <th scope="col">Date de création</th>
                    <th>Action</th>
                </tr></thead>';
                $contenuePrincipale .= '<tbody>';
                
                foreach ($entreprises as $entreprise) {
                    $contenuePrincipale .= $entreprise;
                }
                
                $contenuePrincipale .= '</tbody></table></div>';
                break;

            // Upload de logo
            case 'upload_logo':
                if(!isset($_GET['id'])) {
                    header("Location: ./index.php?action=afficher");
                    exit;
                }
                header("Location: ./fichier_upload.php?id=".$_GET['id']);
                break;

            // Génération de données fictives
            case 'donnees_fictives':
                if(empty($_POST)) {
                    header("Location: ./index.php?action=afficher");
                    exit;
                }
                
                $nbr = 10;
                if(empty($_POST['nbr']) || $_POST['nbr'] <= 0) {
                    $msg = '
                    <div class="alert alert-danger my-3 p-3">
                        <p>
                            La valeur est vide ou inférieure à 1<br>
                            <a class="btn btn-success mt-3" href="./index.php?action=afficher">Voir les entreprises</a>
                        </p>
                    </div>';
                } else {
                    $nbr = trim(htmlspecialchars($_POST['nbr']));
                    $entreprise->ajouterD($nbr);
                    header("Location: ./index.php");
                }
                break;

            // Action par défaut
            default:
                header("Location: ./index.php?action=afficher");
                break;
        }
    } else {
        header("Location: ./index.php?action=afficher");
    }

    // Inclusion du template
    include 'squelette.php';
?>