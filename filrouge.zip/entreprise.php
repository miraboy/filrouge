<?php

class Entreprise
{
    private int $id;
    private string $logo;
    private string $nom;
    private string $description;
    private string $adresse;
    private string $dateC; // date de création
    private int $nbrEmp; // nombre d'employé

    private $pdo; 

    // Méthode Constructeur
    public function __construct(string $nom = "", string $description = "", string $adresse = "", int $nbrEmp = 1, string $dateC = null)
    {
        $this->pdo = connecter();
        $this->nom = $nom;
        $this->logo = "logo.jpg";//valeur par défaut
        $this->description = $description;
        $this->adresse = $adresse;
        $this->nbrEmp = $nbrEmp;
        $this->dateC = $dateC;
    }

    //Méthode pour définir comment va s'afficher une Entreprise, elle retourne un string
    public function __toString():string{
        
        return " <tr> <th scope='row'> $this->id </th><td> <img src=\"./logo/".$this->logo."\"' style='height: 40px!important;'></td><td> $this->nom </td><td> $this->description </td><td> $this->adresse  </td><td>$this->nbrEmp </td><td> $this->dateC </td><td>
        <a href='./index.php?action=voir&id=$this->id' class='btn btn-success' rel='noopener noreferrer'><i class='fas fa-eye'></i></a>
        <a href='./index.php?action=modification_form&id=$this->id' class='btn btn-warning' rel='noopener noreferrer'><i class='fas fa-pencil-alt'></i></a>
        <a href='./index.php?action=confirmer_suppression&id=$this->id' class='btn btn-danger' rel='noopener noreferrer'><i class='fas fa-trash'></i></a>
        <a href='./index.php?action=upload_logo&id=$this->id' class='btn btn-info' rel='noopener noreferrer'><i class='fas fa-upload'></i></a>
        </td></tr>";
    }

    // Getters
    public function getId() :int { return $this->id; }
    public function getNom() :string { return $this->nom; }
    public function getPhoto() :string { return $this->logo; }
    public function getDescription() :string { return $this->description; }
    public function getAdresse() :string { return $this->adresse; }
    public function getDateC() :string { return $this->dateC; }
    public function getNbrEmp() :string { return $this->nbrEmp; }
    public function getPdo() :PDO { return $this->pdo; }

    // Setters
    public function setId(int $id) { $this->id = $id; }
    public function setNom(string $nom) { $this->nom = $nom; }

    public function setLogo(?string $logo) { 
        //si $logo null passer en paramètre utiliser logo.jpg sinon conserver $logo
        ($logo == null)?$this->logo = "logo.jpg":$this->logo = $logo; 
    }

    public function setDescription(string $description) { $this->description = $description; }
    public function setAdresse(string $adresse) { $this->adresse = $adresse; }

    public function setNbrEmp(int $nbrEmp) { 
        //si $nbrEmp null ou négatif passer en paramètre utiliser 1 sinon conserver $nbrEmp
        ($nbrEmp <= 0 )? $this->nbrEmp = 1 : $this->nbrEmp = $nbrEmp; 
    }
    public function setDateC(string $dateC) { 
        $this->dateC = $dateC;             
    }

    // SCRUD Methods

    // Methode pour rechercher une instance de Entreprise par id dans la base de donnée
     /**
     * @return Entreprise
     */
    public static function rechercherParId( int $id) :Entreprise
    {
        $entreprise = new Entreprise("", "", "", 0, "");
        $pdo = $entreprise->getPdo();
        $sql = "SELECT * FROM entreprises WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':id', $id);
        $stmt->execute();

        $data = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($data) {
            $entreprise = new Entreprise(
                $data['nom'],
                $data['description'],
                $data['adresse'],
                $data['nbrEmp'],
                $data['dateC']
            );
            $entreprise->setId($data['id']);
            return $entreprise;
        } 
        
        return $entreprise;
    
    }
    
    // Méthode pour rechercher les instances de Entreprise dont l'une des propriétés contient une clef dans la base de donnée
    /**
     * @return Entreprise[]
     */
    public static function rechercherParClef($clef) :array
    {
        $entreprise = new Entreprise("", "", "", 0, "");
        $pdo = $entreprise->getPdo();
        $sql = "SELECT * FROM entreprises 
                WHERE nom LIKE :motCle 
                OR description LIKE :motCle 
                OR adresse LIKE :motCle 
                OR id LIKE :motCle 
                OR nbrEmp LIKE :motCle 
                OR dateC LIKE :motCle";

        $stmt = $pdo->prepare($sql);
        $motCleLike = '%' . $clef . '%';
        $stmt->execute([':motCle' => $motCleLike]);

        $resultats = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $entreprises = [];

        foreach ($resultats as $row) {
            $entreprise = new Entreprise(
                $row['nom'],
                $row['description'],
                $row['adresse'],
                $row['nbrEmp'],
                $row['dateC']
            );
            $entreprise->setId($row['id']);
            $entreprises[] = $entreprise;
        }

        return $entreprises;

    }

    // Méthode pour enrégistrer une instance de Entreprise dans la base de donnée
    public function ajouter() :bool
    {
        $sql = "INSERT INTO entreprises (nom, description, adresse,nbrEmp, dateC) VALUES (:nom, :description, :adresse,:nbrEmp, :dateC)";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(':nom', $this->nom);
        $stmt->bindParam(':description', $this->description);
        $stmt->bindParam(':adresse', $this->adresse);
        $stmt->bindParam(':nbrEmp', $this->nbrEmp);
        $stmt->bindParam(':dateC', $this->dateC);
        return $stmt->execute();
    }

    // Methode pour modifier une instance de Entreprise dans la base de donnée suivant l'id
    public function modifier() :bool
    {
        if (!$this->id) {
            throw new Exception("ID requis pour modifier");
        }

        $sql = "UPDATE entreprises SET nom = :nom,logo = :logo, description = :description, adresse = :adresse, nbrEmp = :nbrEmp, dateC = :dateC WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(':nom', $this->nom);
        $stmt->bindParam(':logo', $this->logo);
        $stmt->bindParam(':description', $this->description);
        $stmt->bindParam(':adresse', $this->adresse);
        $stmt->bindParam(':nbrEmp', $this->nbrEmp);
        $stmt->bindParam(':dateC', $this->dateC);
        $stmt->bindParam(':id', $this->id);
        
        return $stmt->execute();
    }
    
    // Methode pour modifier la propriété logo d'une instance de Entreprise dans la base de donnée
    public function modifierLogo() :bool
    {
        if (!$this->id) {
            throw new Exception("ID requis pour modifier");
        }

        $sql = "UPDATE entreprises SET logo = :logo WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(':logo', $this->logo);
        $stmt->bindParam(':id', $this->id);
        
        return $stmt->execute();
    }
    
    // Methode pour supprimer une instance une instance de Entreprise de la base de donnée
    public function supprimer() :bool
    {

        if (!isset($this->id) || $this->id === 0) {
        return false;
    }

        $sql = "DELETE FROM entreprises WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(':id', $this->id);
        return $stmt->execute();
    }

    // Méthode pour enrégistrer $nbr instance(s) de Entreprise dans la base de donnée
    public function ajouterD(int $nbr = 10):void{
        $i=0;
        for ($i=0; $i < $nbr; $i++) { 
            $entreprise = new Entreprise("Teck", "vente de produit teck", "paris", 108, "19-05-2000");
            $entreprise->ajouter();
        }
    }

    // Méthode pour réccupérer dans un tableau toutes les instances de Entreprise depuis la base de donnée
    /**
     * @return Entreprise[]
     */
    public function getAll(): array {
        $sql = "SELECT * FROM entreprises";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute();
    
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC); // Utilisation de fetchAll au lieu de fetch
        $entreprises = [];
    
        // Vérification que des données ont été récupérées
        if ($data) {
            foreach ($data as $row) {
                // Instantiation d'une nouvelle Entreprise avec les données récupérées
                $entreprise = new Entreprise(
                    $row['nom'],
                    $row['description'],
                    $row['adresse'],
                    $row['nbrEmp'],
                    $row['dateC']
                );
                $entreprise->setId($row['id']);
                $entreprise->setLogo($row['logo']);
                // Ajout de l'entreprise dans le tableau
                $entreprises[] = $entreprise;
            }
        }
    
        return $entreprises;
    }

}

?>
